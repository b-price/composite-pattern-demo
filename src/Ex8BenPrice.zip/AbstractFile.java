public interface AbstractFile {
    void ls();
}
